/**
 * @fileoverview Unit test for getting users based on their MongoID / userId
 * @access Protected
 */