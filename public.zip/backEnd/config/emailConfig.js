/**
 * @description Storing nodemailer config
 */

const service = 'gmail',
    user = 'jithin@gmail.com',
    password = 'Jithin12!';

module.exports = {
    service,
    user,
    password
}
