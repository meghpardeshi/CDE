/**
 * @fileoverview Action for user forgot password.
 * @todo implement
 */