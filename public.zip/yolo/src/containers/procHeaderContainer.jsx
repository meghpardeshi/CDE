import React from 'react';
import ProcHeader from '../components/shared/ProcHeader/ProcHeader';

export default class ProcHeaderContainer extends React.Component {
    render() {
        return(
            <ProcHeader />
        )
    }
}